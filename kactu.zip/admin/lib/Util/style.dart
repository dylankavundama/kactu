import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

Color CouleurPrincipale = Colors.amber;

TextStyle TitreStyle = GoogleFonts.abel(fontSize: 24, color: Colors.black);

TextStyle TitreStyleWhite = GoogleFonts.abel(fontSize: 24, color: Colors.white);

TextStyle SousTStyle =
    GoogleFonts.actor(fontSize: 18, color: Colors.teal.shade400);

TextStyle DescStyle = GoogleFonts.abel(fontSize: 19, color: Colors.black);

// ignore: non_constant_identifier_names
var Adress_IP = 'https://royalrisingplus.com/ib_app';
