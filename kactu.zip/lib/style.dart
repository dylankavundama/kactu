import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

Color CouleurPrincipale = Colors.amber;

TextStyle TitreStyle = GoogleFonts.abel(fontSize: 24, color: Colors.black);

TextStyle TitreStyleWhite = GoogleFonts.abel(fontSize: 24, color: Colors.white);

TextStyle SousTStyle =
    GoogleFonts.actor(fontSize: 18, color: Colors.green.shade400);

TextStyle DescStyle = GoogleFonts.abel(fontSize: 18, color: Colors.black);
var Adress_IP = 'https://royalrisingplus.com/ib_app';
