import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

// ignore: non_constant_identifier_names
Color CouleurPrincipale = Colors.amber;

TextStyle TitreStyle = GoogleFonts.acme(fontSize: 24, color: Colors.black);

TextStyle TitreStyleWhite = GoogleFonts.abel(fontSize: 24, color: Colors.white);

TextStyle SousTStyle =
    GoogleFonts.abel(fontSize: 18, color: Colors.black);

TextStyle DescStyle = GoogleFonts.actor(fontSize: 19, color: Colors.black);

// ignore: non_constant_identifier_names
var Adress_IP = 'https://royalrisingplus.com/ib_app';
